'''
Load and post-process OpenFOAM simulations. \\
.vtk files will be exported as images through PyVista. \\
.dat files will be plotted through matplotlib.

Maintainer: TheBusyDev <https://github.com/TheBusyDev/>
'''